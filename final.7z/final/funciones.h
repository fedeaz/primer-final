#include <stdio.h>
#include <stdlib.h>
#include "ArrayList.h"




int menuModifica();
int cargarPersonas(ArrayList* , char* );
