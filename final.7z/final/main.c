#include <stdio.h>
#include <stdlib.h>

#include "funciones.h"
#include "ArrayList.h"
#include "datos.h"


int main()
{

    //menuModifica();
    char seguir = 's';
    int opcion=0;
    eNumero* num;
    ArrayList* alta = al_newArrayList();

    while(seguir=='s')
    {

    printf("1- Altas\n");
    printf("2- completar\n");
    printf("3- listar\n");
    printf("4- generar\n");
    printf("5- Salir\n");

    scanf("%d",&opcion);

    switch(opcion)
        {
            case 1:
                cargarPersonas(alta,"datos.csv");

                mostrarTodos(alta);
                system("pause");
                break;
            case 2:
                vali1(alta,num);
                mostrarTodos(alta);
                system("pause");
                break;
            case 3:
                system("pause");
                break;
            case 4:
                system("pause");
                break;
            case 5:
                seguir = 'n';
                break;
        }
    }


    return 0;
}
