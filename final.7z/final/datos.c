#include <stdio.h>
#include <stdlib.h>

#include "funciones.h"
#include "ArrayList.h"
#include "datos.h"

void mostrarUsuario(eNumero* num)
{
    printf("%-5d %5s\t\t %5d\t %5d %5d\n",num->numero, num->nombre, num->par, num->impar, num->primo );
}

void mostrarTodos(ArrayList* num)
{
    int i;
    eNumero* unUsuario=newUsuario();
    unUsuario= num->get(num,1);
    printf("Numero     Nombre                    par    impar  primo\n\n");
    mostrarUsuario(unUsuario);
    system("pause");
    for(i=0; i<num->len(num); i++)
            {
                unUsuario= num->get(num,i);
                mostrarUsuario(unUsuario);
            }
}

//FUNCI�N CONSTRUCTORA
eNumero* newUsuario()
{
    eNumero* retorno=NULL;
    eNumero* nuevoUsuario=(eNumero*)malloc(sizeof(eNumero));
    if(nuevoUsuario!=NULL)
    {
        strcpy(nuevoUsuario->nombre,"");
        nuevoUsuario->numero=0;
        nuevoUsuario->par=0;
        nuevoUsuario->impar=0;
        nuevoUsuario->primo=0;
        retorno = nuevoUsuario;
    }
    else
    {
          printf("Error no se consiguio memoria");
          exit(1);
    }
     return retorno;
}

void vali1(ArrayList* num,eNumero* numero)
{
    int i;

        for(i=0; i<num->len(num); i++)
            {
                if(numero->numero %2 ==0)
                {
                    numero->par ==1;
                }
                else
                {
                    numero->impar ==1;
                }
           }
}
